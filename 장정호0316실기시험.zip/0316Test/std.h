#pragma once
#include <Windows.h>
#include<tchar.h>
//You must have make Resource-Dialog 
#include"resource.h"

#include"SHAPE.h"