#pragma once

typedef struct tagSHAPE
{
	COLORREF color;
	POINT pt;
}SHAPE;


